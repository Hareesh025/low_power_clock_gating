# Duty-cycle sweep simulation and power analysis
# Usage: source duty_cycle_sweep.tcl

proc run_duty_cycle {active_cycles total_cycles} {
    set duty_pct [expr {int($active_cycles * 100.0 / $total_cycles)}]
    set sim_dir "sim_dc_${duty_pct}"
    
    puts "=== Running Duty Cycle: ${duty_pct}% (${active_cycles}/${total_cycles}) ==="
    
    # Create simulation project
    create_project -force $sim_dir ./$sim_dir
    add_files {alu32.v reg_bank.v processing_unit.v baseline_top.v low_power_top.v tb_duty_cycle.v}
    set_property top tb_duty_cycle [current_fileset -simset]
    set_property generic {{ACTIVE_CYCLES=$active_cycles} {TOTAL_CYCLES=$total_cycles}} [get_files tb_duty_cycle.v]
    
    # Launch simulation with SAIF output
    launch_simulation
    set sim [get_simulations sim_1]
    set_property xsim.simulate.runtime {"${total_cycles}0 ns"} $sim
    
    # Generate SAIF for power analysis
    # Note: SAIF generation requires specific xsim commands
    # For now, run behavioral simulation
    run all
    
    close_project
}

# Run all duty cycles
run_duty_cycle 100 1000   # 10%
run_duty_cycle 250 1000   # 25%
run_duty_cycle 500 1000   # 50%
run_duty_cycle 750 1000   # 75%
run_duty_cycle 1000 1000  # 100%

puts "Duty-cycle sweep complete"