open_saif C:/Users/yarab/low_power_clock_gating/baseline.saif
log_saif [get_objects -r *]
run all
close_saif
puts "BASELINE_SAIF_CREATED"
puts "SIZE=[file size C:/Users/yarab/low_power_clock_gating/baseline.saif]"
