reset_switching_activity -all
read_saif C:/Users/yarab/low_power_clock_gating/low_power.saif -strip_path tb_power_low/dut
report_power -file C:/Users/yarab/low_power_clock_gating/low_power_power_final.rpt
puts "LOW_POWER_REPORT_CREATED"
