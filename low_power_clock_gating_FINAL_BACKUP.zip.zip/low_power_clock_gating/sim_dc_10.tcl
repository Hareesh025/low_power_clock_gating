create_project -force sim_dc_10 ./sim_dc_10
add_files {alu32.v reg_bank.v processing_unit.v baseline_top.v low_power_top.v tb_dc_10.v}
set_property top tb_dc_10 [current_fileset -simset]
launch_simulation
run all
close_project