LOW POWER CLOCK GATING - FAST FINISH PACK

Copy these files into:
C:\Users\yarab\low_power_clock_gating

Files:
- tb_power_low.v       Dedicated low-power activity testbench
- tb_power_base.v      Dedicated baseline activity testbench
- run_saif_low.tcl     Low-power SAIF commands
- run_saif_base.tcl    Baseline SAIF commands
- run_power_low.tcl    Low-power power-report commands
- run_power_base.tcl   Baseline power-report commands

IMPORTANT:
I cannot directly access or execute Vivado on your Windows C: drive from this
chat. These files are prepared for your exact project path.

WORKLOAD:
100 active + 300 idle + 100 active + 300 idle + 200 active
= 300 active / 1000 cycles = 30% active.

FLOW:
1. Add both .v files as Simulation Sources.
2. Set simulation top = tb_power_low.
3. Run Behavioral Simulation.
4. In the active simulator Tcl console, paste/run run_saif_low.tcl.
5. Set simulation top = tb_power_base.
6. Run Behavioral Simulation.
7. Run run_saif_base.tcl.
8. Open the LOW-POWER implemented design and run run_power_low.tcl.
9. Open the BASELINE implemented design and run run_power_base.tcl.

Do not use tb_compare.saif as the final power activity file.
