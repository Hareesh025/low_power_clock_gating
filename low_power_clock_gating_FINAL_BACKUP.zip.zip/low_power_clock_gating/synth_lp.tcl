# Synthesis script for low_power_top
create_project -force lp_synth ./lp_synth
add_files {alu32.v reg_bank.v processing_unit.v low_power_top.v}
set_property top low_power_top [current_fileset]
add_files -fileset constrs_1 clock_constraints.xdc
launch_runs synth_1
wait_on_run synth_1
report_utilization -file low_power_top_utilization_synth.rpt
report_timing_summary -file low_power_top_timing_synth.rpt
close_project