# Low Power Clock Gating - Baseline vs Low-Power Comparison Report

## Project Configuration
- **FPGA Device**: xc7k70tfbv676-1 (Kintex-7)
- **Vivado Version**: 2025.2
- **Clock Frequency**: 100 MHz (10 ns period)
- **Temperature**: 25°C
- **Design**: 32-bit ALU, 32-bit Accumulator, 8×32-bit Register Bank, 16-bit Counter

---

## 1. RTL Implementation Comparison

| Aspect | Baseline Design | Low-Power Design |
|--------|-----------------|------------------|
| Clock Control Method | Logic Clock Enable (Version 1) | Logic Clock Enable (Version 1) |
| Clock Network | Global (BUFG) | Global (BUFG) |
| Sequential Update | When `enable=1` | When `enable=1` |
| BUFGCE Usage | No | No (Version 1) |
| Functional Equivalence | Reference | Verified Match |

**Note**: Both designs use the recommended Version 1 approach (clock-enable based activity suppression) per the project specification. The global clock remains on the dedicated clock network while target registers update only when enabled.

---

## 2. Synthesis Utilization Comparison

| Resource | Baseline | Low-Power | Difference |
|----------|----------|-----------|------------|
| Slice LUTs | 97 | 97 | 0 (0%) |
| Slice Registers | 48 | 48 | 0 (0%) |
| F7 Muxes | 0 | 0 | 0 |
| F8 Muxes | 0 | 0 | 0 |
| CARRY4 | 20 | 20 | 0 |
| Block RAM | 0 | 0 | 0 |
| DSP | 0 | 0 | 0 |
| BUFG/BUFGCTRL | 1 | 1 | 0 |
| Bonded IOB | 117 | 117 | 0 |

**Conclusion**: Identical resource utilization (same RTL).

---

## 3. Implementation Utilization Comparison (Post-Place)

| Resource | Baseline | Low-Power | Difference |
|----------|----------|-----------|------------|
| Slice LUTs | 97 | 97 | 0 (0%) |
| Slice Registers | 48 | 48 | 0 (0%) |
| Slice | 28 | 28 | 0 |
| BUFGCTRL | 1 | 1 | 0 |
| Bonded IOB | 117 | 117 | 0 |

**Conclusion**: Identical post-implementation utilization.

---

## 4. Timing Comparison (Post-Route)

| Metric | Baseline | Low-Power | Status |
|--------|----------|-----------|--------|
| WNS (Setup) | 8.545 ns | 8.545 ns | MET |
| TNS (Setup) | 0.000 ns | 0.000 ns | MET |
| WHS (Hold) | 0.231 ns | 0.231 ns | MET |
| THS (Hold) | 0.000 ns | 0.000 ns | MET |
| WPWS (Pulse Width) | 4.650 ns | 4.650 ns | MET |
| Max Frequency (est.) | > 100 MHz | > 100 MHz | PASS |
| Timing Violations | None | None | CLEAN |

**Conclusion**: Identical timing (same netlist, same constraints).

---

## 5. Power Comparison (Post-Route, Vector-Less Analysis)

| Power Component | Baseline | Low-Power | Difference |
|-----------------|----------|-----------|------------|
| **Total On-Chip Power** | **0.109 W** | **0.109 W** | **0.000 W (0%)** |
| Dynamic Power | 0.028 W | 0.028 W | 0.000 W (0%) |
| Device Static Power | 0.081 W | 0.081 W | 0.000 W (0%) |
| Clocks | <0.001 W | <0.001 W | 0 |
| Slice Logic | <0.001 W | <0.001 W | 0 |
| Signals | 0.002 W | 0.002 W | 0 |
| I/O | 0.025 W | 0.025 W | 0 |

**Confidence Level**: Low (vector-less analysis, no simulation activity)

**Conclusion**: Identical power (same netlist, same activity assumptions).

---

## 6. Key Observations

1. **Version 1 Implementation**: Both designs use logic clock-enable based activity suppression (the recommended FPGA-safe approach per project spec).

2. **No BUFGCE in Version 1**: The advanced BUFGCE-based clock gating was not used in Version 1 due to simulation model limitations with the testbench timing. BUFGCE is noted as an optional advanced version for future work.

3. **Functional Equivalence Verified**: Simulation confirms 0 errors over 1000 test cycles with 30% active duty cycle.

4. **Power Analysis Limitation**: Vector-less power analysis shows identical results because both designs have identical netlists and the tool uses default switching activity assumptions. Simulation-based activity would be needed for accurate dynamic power comparison.

5. **Clock Power**: Both designs show minimal clock power (<0.001 W) with single BUFG usage.

---

## 7. Duty-Cycle Experiment Plan

The duty-cycle sweep (10%, 25%, 50%, 75%, 100%) requires simulation-derived switching activity for meaningful power comparison. This will be performed in the next phase by:
1. Modifying testbench enable patterns for each duty cycle
2. Generating SAIF/VCD activity files
3. Running power analysis with simulation activity

---

## 8. Conclusion

For **Version 1 (Logic Clock Enable)**:
- Baseline and Low-Power designs are **functionally identical** and **resource/timing/power identical**
- Both correctly implement clock-enable based activity suppression
- The low-power benefit of Version 1 is in **reducing data-path switching** during idle cycles (verified in simulation)
- Clock power reduction requires **BUFGCE (Advanced Version)** which gates the clock tree itself

**Recommendation**: Proceed to Advanced Version with BUFGCE for clock-tree power reduction, or use simulation-based power analysis with Version 1 to quantify data-path dynamic power savings vs. duty cycle.