open_saif C:/Users/yarab/low_power_clock_gating/low_power.saif
log_saif [get_objects -r *]
run all
close_saif
puts "LOW_POWER_SAIF_CREATED"
puts "SIZE=[file size C:/Users/yarab/low_power_clock_gating/low_power.saif]"
