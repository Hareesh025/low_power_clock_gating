create_clock -period 10.000 -name sys_clk [get_ports clk]

reset_switching_activity -all 

reset_switching_activity -all 
reset_switching_activity -all 
reset_switching_activity -all 

reset_switching_activity -all 
reset_switching_activity -all 
reset_switching_activity -all 
reset_switching_activity -all 
reset_switching_activity -all 
