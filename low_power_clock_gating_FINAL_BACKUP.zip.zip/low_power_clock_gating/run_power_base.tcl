reset_switching_activity -all
read_saif C:/Users/yarab/low_power_clock_gating/baseline.saif -strip_path tb_power_base/dut
report_power -file C:/Users/yarab/low_power_clock_gating/baseline_power_final.rpt
puts "BASELINE_REPORT_CREATED"
