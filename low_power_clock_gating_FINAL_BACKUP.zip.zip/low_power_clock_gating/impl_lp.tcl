# Implementation script for low_power_top
open_project lp_synth/lp_synth.xpr
launch_runs impl_1 -to_step write_bitstream
wait_on_run impl_1
close_project