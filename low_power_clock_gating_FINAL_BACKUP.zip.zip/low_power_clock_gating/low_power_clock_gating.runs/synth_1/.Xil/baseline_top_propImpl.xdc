set_property SRC_FILE_INFO {cfile:C:/Users/yarab/low_power_clock_gating/clock_constraints.xdc rfile:../../../clock_constraints.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:3 export:INPUT save:INPUT read:READ} [current_design]
reset_switching_activity -all
set_property src_info {type:XDC file:1 line:5 export:INPUT save:INPUT read:READ} [current_design]
reset_switching_activity -all
set_property src_info {type:XDC file:1 line:6 export:INPUT save:INPUT read:READ} [current_design]
reset_switching_activity -all
set_property src_info {type:XDC file:1 line:7 export:INPUT save:INPUT read:READ} [current_design]
reset_switching_activity -all
