//Duty-cycle sweep testbench generator
`timescale 1ns/1ps

module tb_duty_cycle #(
    parameter integer ACTIVE_CYCLES = 100,
    parameter integer TOTAL_CYCLES = 1000
);

    reg clk;
    reg reset;
    reg enable;

    reg [31:0] A;
    reg [31:0] B;
    reg [1:0]  op;

    wire [31:0] baseline_result;
    wire [15:0] baseline_counter;

    wire [31:0] low_power_result;
    wire [15:0] low_power_counter;

    integer cycle_count;
    integer error_count;

    // Baseline Design
    baseline_top baseline_inst (
        .clk(clk),
        .reset(reset),
        .enable(enable),
        .A(A),
        .B(B),
        .op(op),
        .result(baseline_result),
        .counter(baseline_counter)
    );

    // Low-Power Design
    low_power_top low_power_inst (
        .clk(clk),
        .reset(reset),
        .enable(enable),
        .A(A),
        .B(B),
        .op(op),
        .result(low_power_result),
        .counter(low_power_counter)
    );

    // 100 MHz Clock
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    // Enable pattern generator
    initial begin
        reset       = 1'b1;
        enable      = 1'b1;
        A           = 32'd10;
        B           = 32'd5;
        op          = 2'b00;
        cycle_count = 0;
        error_count = 0;

        repeat (2) @(posedge clk);
        @(negedge clk);
        reset = 1'b0;

        for (cycle_count = 0; cycle_count < TOTAL_CYCLES; cycle_count = cycle_count + 1) begin
            // Enable pattern based on ACTIVE_CYCLES percentage
            if (cycle_count < ACTIVE_CYCLES)
                enable = 1'b1;
            else
                enable = 1'b0;

            // ALU workload
            if (cycle_count < 250) begin
                A  = 32'd10;
                B  = 32'd5;
                op = 2'b00;
            end
            else if (cycle_count < 500) begin
                A  = 32'd100;
                B  = 32'd25;
                op = 2'b01;
            end
            else if (cycle_count < 750) begin
                A  = 32'hAAAA5555;
                B  = 32'h12345678;
                op = 2'b10;
            end
            else begin
                A  = 32'hFFFF0000;
                B  = 32'h00FF00FF;
                op = 2'b11;
            end

            @(posedge clk);
        end

        #10;
        $display("Duty Cycle Test: ACTIVE_CYCLES=%0d/%0d (%.0f%%)", ACTIVE_CYCLES, TOTAL_CYCLES, (ACTIVE_CYCLES*100.0/TOTAL_CYCLES));
        $display("Error count = %0d", error_count);
        $finish;
    end

    // Functional Equivalence Check
    always @(posedge clk) begin
        #1;
        if (!reset) begin
            if (baseline_result !== low_power_result) begin
                $display("ERROR: RESULT mismatch | Baseline=%h LowPower=%h", baseline_result, low_power_result);
                error_count = error_count + 1;
            end
            if (baseline_counter !== low_power_counter) begin
                $display("ERROR: COUNTER mismatch | Baseline=%d LowPower=%d", baseline_counter, low_power_counter);
                error_count = error_count + 1;
            end
        end
    end

endmodule