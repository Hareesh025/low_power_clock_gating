# Simulation script for low_power_clock_gating project
create_project -force sim_project ./sim_project
add_files {alu32.v reg_bank.v processing_unit.v baseline_top.v low_power_top.v tb_compare.v}
set_property top tb_compare [current_fileset -simset]
launch_simulation
run all
close_project