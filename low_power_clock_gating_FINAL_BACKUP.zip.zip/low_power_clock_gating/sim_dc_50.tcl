create_project -force sim_dc_50 ./sim_dc_50
add_files {alu32.v reg_bank.v processing_unit.v baseline_top.v low_power_top.v tb_dc_50.v}
set_property top tb_dc_50 [current_fileset -simset]
launch_simulation
run all
close_project