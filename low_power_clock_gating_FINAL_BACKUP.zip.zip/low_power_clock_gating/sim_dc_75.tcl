create_project -force sim_dc_75 ./sim_dc_75
add_files {alu32.v reg_bank.v processing_unit.v baseline_top.v low_power_top.v tb_dc_75.v}
set_property top tb_dc_75 [current_fileset -simset]
launch_simulation
run all
close_project