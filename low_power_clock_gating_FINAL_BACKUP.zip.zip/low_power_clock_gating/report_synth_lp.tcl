# Open synthesized design and generate reports
open_project lp_synth/lp_synth.xpr
open_run synth_1 -name low_power_top
report_utilization -file low_power_top_utilization_synth.rpt
report_timing_summary -file low_power_top_timing_synth.rpt
close_project